from __future__ import annotations

from dataclasses import asdict

import numpy as np
import pandas as pd

from .config import FitConfig
from .data import ResponseMatrix, coerce_responses
from .estimator import AlternatingRandomItemIRT


class TransposedIRT:
    """Normal random-item 1PL or 2PL estimator.

    Parameters mirror the two specifications in the paper. For a 2PL,
    ``covariance='diagonal'`` fixes the difficulty/log-discrimination covariance
    to zero, while ``covariance='full'`` estimates it.
    """

    def __init__(
        self,
        model: str = "2pl",
        covariance: str | None = None,
        *,
        integration: str = "aghq",
        max_iterations: int = 200,
        item_newton_steps: int = 6,
        objective_tolerance: float = 1e-5,
        prediction_tolerance: float = 1e-4,
        convergence_patience: int = 5,
        min_iterations: int = 10,
        random_state: int = 0,
        verbose: bool = False,
        aghq_orders: tuple[int, ...] = (7, 11, 15, 21),
        aghq_max_iterations: int = 50,
        aghq_min_iterations: int = 2,
        aghq_patience: int = 3,
        aghq_batch_size: int = 512,
        aghq_inner_theta_tolerance: float = 2e-3,
        aghq_inner_population_tolerance: float = 2e-3,
        aghq_inner_prediction_tolerance: float = 5e-4,
        aghq_inner_objective_tolerance: float = 1e-5,
        aghq_theta_tolerance: float = 1e-2,
        aghq_population_tolerance: float = 1e-2,
        aghq_correlation_tolerance: float = 1e-2,
        aghq_prediction_tolerance: float = 2e-3,
        aghq_objective_tolerance: float = 1e-4,
        aghq_score_tolerance: float = 1e-3,
    ) -> None:
        model = model.lower()
        covariance = covariance or ("diagonal" if model == "1pl" else "full")
        self.config = FitConfig(
            model=model,
            covariance=covariance,
            integration=integration,
            max_iterations=max_iterations,
            item_newton_steps=item_newton_steps,
            objective_tolerance=objective_tolerance,
            prediction_tolerance=prediction_tolerance,
            convergence_patience=convergence_patience,
            min_iterations=min_iterations,
            random_state=random_state,
            verbose=verbose,
            aghq_orders=aghq_orders,
            aghq_max_iterations=aghq_max_iterations,
            aghq_min_iterations=aghq_min_iterations,
            aghq_patience=aghq_patience,
            aghq_batch_size=aghq_batch_size,
            aghq_inner_theta_tolerance=aghq_inner_theta_tolerance,
            aghq_inner_population_tolerance=aghq_inner_population_tolerance,
            aghq_inner_prediction_tolerance=aghq_inner_prediction_tolerance,
            aghq_inner_objective_tolerance=aghq_inner_objective_tolerance,
            aghq_theta_tolerance=aghq_theta_tolerance,
            aghq_population_tolerance=aghq_population_tolerance,
            aghq_correlation_tolerance=aghq_correlation_tolerance,
            aghq_prediction_tolerance=aghq_prediction_tolerance,
            aghq_objective_tolerance=aghq_objective_tolerance,
            aghq_score_tolerance=aghq_score_tolerance,
        )
        self._estimator: AlternatingRandomItemIRT | None = None
        self._responses: ResponseMatrix | None = None

    def fit(self, responses) -> "TransposedIRT":
        """Fit a subject-by-item matrix and return this estimator."""

        response_matrix = coerce_responses(responses)
        self._estimator = AlternatingRandomItemIRT(self.config).fit(
            response_matrix.to_numpy()
        )
        self._responses = response_matrix
        return self

    @property
    def abilities_(self) -> np.ndarray:
        self._check_fitted()
        return self._estimator.theta_.copy()

    @property
    def stopping_reason_(self) -> str:
        self._check_fitted()
        return self._estimator.summary()["stopping_reason"]

    def predict(self, subject, item) -> np.ndarray:
        """Predict response probabilities for paired subject and item indices."""

        self._check_fitted()
        subject = np.asarray(subject, dtype=int)
        item = np.asarray(item, dtype=int)
        if subject.shape != item.shape:
            raise ValueError("subject and item indices must have the same shape")
        if np.any((subject < 0) | (subject >= self._responses.n_subjects)):
            raise IndexError("subject index is out of range")
        if np.any((item < 0) | (item >= self._responses.n_items)):
            raise IndexError("item index is out of range")
        values = self._estimator.predict_pairs(subject.ravel(), item.ravel())
        return values.reshape(subject.shape)

    def predict_matrix(self) -> np.ndarray:
        """Predict every fitted subject-item cell."""

        self._check_fitted()
        subjects = np.arange(self._responses.n_subjects).repeat(self._responses.n_items)
        items = np.tile(np.arange(self._responses.n_items), self._responses.n_subjects)
        return self.predict(subjects, items).reshape(self._responses.shape)

    def score(self, responses, theta_init=None) -> np.ndarray:
        """Score new subjects on the fitted item bank without refitting it."""

        self._check_fitted()
        matrix = coerce_responses(responses)
        if matrix.n_items != self._responses.n_items:
            raise ValueError(f"responses must have {self._responses.n_items} item columns")
        return self._estimator.score_subjects(matrix.to_numpy(), theta_init)

    def abilities(self) -> pd.DataFrame:
        self._check_fitted()
        identifiers = self._responses.subject_ids or [
            str(i) for i in range(self._responses.n_subjects)
        ]
        return pd.DataFrame({"subject_id": identifiers, "theta": self.abilities_})

    def items(self) -> pd.DataFrame:
        self._check_fitted()
        frame = self._estimator.item_frame()
        identifiers = self._responses.item_ids or [
            str(i) for i in range(self._responses.n_items)
        ]
        frame.insert(1, "item_label", identifiers)
        return frame

    def history(self) -> pd.DataFrame:
        self._check_fitted()
        return self._estimator.history_frame()

    def integration_diagnostics(self) -> pd.DataFrame:
        self._check_fitted()
        return self._estimator.integration_frame()

    def estimate_inference(
        self,
        clusters=None,
        *,
        posterior_draw_target: int = 32_000,
        maximum_draws_per_item: int = 32,
        resampling_seeds: tuple[int, ...] = (17041, 29063),
        batch_size: int | None = None,
        check_order_stability: bool = True,
    ) -> pd.DataFrame:
        """Estimate joint sandwich standard errors and 95% Wald intervals.

        ``clusters`` may contain one label per item. With no labels, each item
        is treated as an independent score cluster. The returned table uses
        natural scales for item-population standard deviations and correlation.
        """

        self._check_fitted()
        result = self._estimator.estimate_inference(
            clusters=None if clusters is None else np.asarray(clusters),
            posterior_draw_target=posterior_draw_target,
            maximum_draws_per_item=maximum_draws_per_item,
            resampling_seeds=resampling_seeds,
            batch_size=batch_size,
            check_order_stability=check_order_stability,
        )
        table = result.parameter_table.copy()
        identifiers = self._responses.subject_ids or [
            str(i) for i in range(self._responses.n_subjects)
        ]
        capability = table["parameter_type"].eq("capability")
        table.loc[capability, "parameter"] = [
            f"theta[{identifier}]" for identifier in identifiers
        ]
        return table

    def inference_diagnostics(self) -> dict:
        self._check_fitted()
        if self._estimator.inference_result_ is None:
            raise RuntimeError("Call estimate_inference before requesting diagnostics.")
        return dict(self._estimator.inference_result_.diagnostics)

    def covariance(self, kind: str = "sandwich") -> pd.DataFrame:
        """Return the fitted free-coordinate covariance matrix."""

        self._check_fitted()
        result = self._estimator.inference_result_
        if result is None:
            raise RuntimeError("Call estimate_inference before requesting covariance.")
        choices = {
            "sandwich": result.sandwich_covariance,
            "model_based": result.model_based_covariance,
        }
        if kind not in choices:
            raise ValueError("kind must be 'sandwich' or 'model_based'")
        labels = list(result.diagnostics["free_parameter_labels"])
        identifiers = self._responses.subject_ids or [
            str(i) for i in range(self._responses.n_subjects)
        ]
        labels[: self._responses.n_subjects] = [
            f"theta[{identifier}]" for identifier in identifiers
        ]
        return pd.DataFrame(choices[kind], index=labels, columns=labels)

    def population(self) -> pd.DataFrame:
        self._check_fitted()
        return self._estimator.latent_correlation_frame()

    def summary(self) -> dict:
        self._check_fitted()
        result = self._estimator.summary()
        result["config"] = asdict(self.config)
        return result

    def _check_fitted(self) -> None:
        if self._estimator is None:
            raise RuntimeError("Call fit before requesting fitted results.")
