from __future__ import annotations

import copy
from dataclasses import asdict
from typing import Dict, Optional

import numpy as np
import pandas as pd
from scipy.special import logit

from .config import FitConfig
from .data import item_major, theta_start
from .families import NormalFamily
from .inference import InferenceResult, estimate_inference
from .item_step import build_item_stepper
from .models import (
    clamp_probability_numpy,
    irt_probability_numpy,
    natural_item_parameters_numpy,
)
from .posterior import laplace_cubature
from .quadrature import adaptive_gauss_hermite
from .theta_step import update_theta, update_theta_predictive


class AlternatingRandomItemIRT:
    def __init__(self, config: Optional[FitConfig] = None):
        self.config = config or FitConfig()
        self.theta_: Optional[np.ndarray] = None
        self.latent_modes_: Optional[np.ndarray] = None
        self.item_params_: Optional[Dict[str, np.ndarray]] = None
        self.family_ = None
        self.family_moments_ = None
        self.history_ = []
        self.item_hessian_ = None
        self.item_laplace_nll_ = None
        self.item_posterior_covariance_ = None
        self.posterior_nodes_ = None
        self.node_weights_ = None
        self.integration_diagnostics_ = []
        self.laplace_theta_ = None
        self.laplace_population_ = None
        self.stopping_reason_ = "not_started"
        self.failure_iteration_ = None
        self.selected_iteration_ = None
        self.item_responses_ = None
        self.item_mask_ = None
        self.inference_result_: Optional[InferenceResult] = None

    @property
    def model_dimension(self) -> int:
        return self.config.dimension

    @property
    def population_dimension(self) -> int:
        return self.config.dimension

    def _initial_latent(self, matrix: np.ndarray, theta: np.ndarray) -> np.ndarray:
        dim = self.model_dimension
        observed = np.isfinite(matrix)
        responses = np.nan_to_num(matrix, nan=0.0)
        counts = np.maximum(np.sum(observed, axis=0), 1)
        p = np.sum(responses, axis=0) / counts
        fallback = float(np.nanmean(matrix))
        p = np.where(np.isfinite(p), p, fallback)
        p = clamp_probability_numpy(p, eps=1e-4)
        latent = np.zeros((matrix.shape[1], dim), dtype=float)
        if dim >= 2:
            # A zero alpha vector places the initial discrimination variance on
            # the covariance boundary and can trap the 2PL at a 1PL solution.
            # The first-order logistic slope below gives the population update
            # a finite, data-informed interior start without fitting p separate
            # logistic regressions.
            theta_column = np.asarray(theta, dtype=float)[:, None]
            item_theta_mean = np.sum(observed * theta_column, axis=0) / counts
            centered_theta = theta_column - item_theta_mean
            item_variance = np.sum(observed * centered_theta**2, axis=0) / counts
            covariance = np.sum(
                observed * centered_theta * (responses - p), axis=0
            ) / counts
            information = item_variance * p * (1.0 - p)
            slope = covariance / np.maximum(information, 1e-3)
            slope = np.clip(slope, 0.30, 3.50)
            alpha = np.log(slope)
            alpha -= float(np.mean(alpha))
            latent[:, 1] = alpha
            latent[:, 0] = item_theta_mean - logit(p) / np.exp(alpha)
        else:
            latent[:, 0] = np.mean(theta) - logit(p)
        return np.clip(latent, -10.0, 10.0)

    def _normalize_identification(self, latent, theta):
        if self.family_ is None:
            raise RuntimeError("Family is not initialized.")
        moments = self.family_.moments()
        shift = float(moments.b_center)
        latent = np.asarray(latent, dtype=float).copy()
        theta = np.asarray(theta, dtype=float).copy()
        latent[:, 0] = latent[:, 0] - shift
        theta = theta - shift
        self.family_.affine_normalize_b(shift=shift, scale=1.0)
        return latent, theta, self.family_.moments()

    def _normalize_nodes(self, nodes: np.ndarray, shift: float) -> np.ndarray:
        nodes = np.asarray(nodes, dtype=float).copy()
        nodes[:, :, 0] -= shift
        return nodes

    def _identify_discrimination(self, latent, reference, theta, nodes, weights):
        if self.model_dimension < 2:
            return latent, reference, theta, nodes, 0.0
        alpha_shift = float(np.mean(np.sum(weights * nodes[:, :, 1], axis=1)))
        scale = float(np.exp(np.clip(alpha_shift, -10.0, 10.0)))
        latent = np.asarray(latent, dtype=float).copy()
        reference = np.asarray(reference, dtype=float).copy()
        theta = np.asarray(theta, dtype=float).copy() * scale
        nodes = np.asarray(nodes, dtype=float).copy()
        latent[:, 0] *= scale
        reference[:, 0] *= scale
        nodes[:, :, 0] *= scale
        latent[:, 1] -= alpha_shift
        reference[:, 1] -= alpha_shift
        nodes[:, :, 1] -= alpha_shift
        return latent, reference, theta, nodes, alpha_shift

    def _predict_with_nodes(self, theta, nodes, weights, person_index, item_index):
        selected = nodes[item_index]
        n_pairs, n_nodes, dimension = selected.shape
        params = natural_item_parameters_numpy(
            selected.reshape(n_pairs * n_nodes, dimension),
            model_dim=self.model_dimension,
            a_scale=1.0,
        )
        probability = irt_probability_numpy(
            theta=np.repeat(theta[person_index], n_nodes),
            a=params["a"],
            b=params["b"],
        ).reshape(n_pairs, n_nodes)
        weights = np.asarray(weights)
        selected_weights = (
            weights[item_index]
            if weights.ndim == 2
            else np.broadcast_to(weights, probability.shape)
        )
        return np.sum(probability * selected_weights, axis=1)

    def _posterior_score_max(
        self, theta, nodes, weights, item_responses, item_mask
    ) -> float:
        score = np.zeros(len(theta), dtype=float)
        batch_size = self.config.aghq_batch_size
        for start in range(0, len(nodes), batch_size):
            stop = min(start + batch_size, len(nodes))
            batch_nodes = nodes[start:stop]
            item_count, node_count, dimension = batch_nodes.shape
            parameters = natural_item_parameters_numpy(
                batch_nodes.reshape(-1, dimension), self.model_dimension
            )
            discrimination = parameters["a"].reshape(item_count, node_count)
            difficulty = parameters["b"].reshape(item_count, node_count)
            probability = irt_probability_numpy(
                theta=np.asarray(theta)[None, :, None],
                a=discrimination[:, None, :],
                b=difficulty[:, None, :],
            )
            residual = item_responses[start:stop, :, None] - probability
            contribution = (
                item_mask[start:stop, :, None]
                * residual
                * discrimination[:, None, :]
                * weights[start:stop, None, :]
            )
            score += np.sum(contribution, axis=(0, 2))
        observed_per_subject = np.maximum(np.sum(item_mask, axis=0), 1.0)
        return float(np.max(np.abs(score) / observed_per_subject))

    @staticmethod
    def _posterior_covariance(nodes, weights):
        means = np.einsum("jk,jkd->jd", weights, nodes)
        centered = nodes - means[:, None, :]
        return np.einsum("jk,jkd,jke->jde", weights, centered, centered)

    @staticmethod
    def _population_vector(moments) -> np.ndarray:
        covariance = np.asarray(moments.raw_cov, dtype=float)
        upper = covariance[np.triu_indices_from(covariance)]
        return np.concatenate((np.asarray(moments.raw_mean, dtype=float), upper))

    def fit(
        self,
        matrix: np.ndarray,
        theta_init: Optional[np.ndarray] = None,
        latent_init: Optional[np.ndarray] = None,
    ) -> "AlternatingRandomItemIRT":
        matrix = np.asarray(matrix, dtype=float)
        self.history_ = []
        self.failure_iteration_ = None
        self.selected_iteration_ = None
        person_responses = np.nan_to_num(matrix, nan=0.0)
        person_mask = (~np.isnan(matrix)).astype(float)
        item_responses, item_mask = item_major(matrix)
        self.item_responses_ = item_responses
        self.item_mask_ = item_mask
        self.inference_result_ = None
        observed_flat = np.flatnonzero(person_mask.ravel())
        sample_size = min(self.config.convergence_sample_size, observed_flat.size)
        sample_positions = np.linspace(0, observed_flat.size - 1, sample_size, dtype=int)
        sampled_flat = observed_flat[sample_positions]
        sampled_person = sampled_flat // matrix.shape[1]
        sampled_item = sampled_flat % matrix.shape[1]

        theta = (
            theta_start(matrix)
            if theta_init is None
            else np.asarray(theta_init, dtype=float).copy()
        )
        if theta.shape[0] != matrix.shape[0]:
            raise ValueError("theta_init has incompatible length.")
        latent = (
            self._initial_latent(matrix, theta)
            if latent_init is None
            else np.asarray(latent_init, dtype=float).copy()
        )
        if latent.shape != (matrix.shape[1], self.model_dimension):
            raise ValueError("latent_init has incompatible shape.")
        self.family_ = NormalFamily(dim=self.population_dimension, config=self.config)
        self.family_.fit(latent[:, : self.population_dimension])
        latent, theta, moments = self._normalize_identification(latent, theta)
        self.family_moments_ = moments
        item_stepper = build_item_stepper(
            model_dim=self.model_dimension,
            family=self.family_,
            newton_steps=self.config.item_newton_steps,
            ridge=self.config.ridge,
        )

        previous_nll = None
        previous_predictions = None
        stable_iterations = 0
        objective_increase_count = 0
        consecutive_objective_increases = 0
        best_nll = np.inf
        best_snapshot = None
        self.stopping_reason_ = "iteration_limit"
        for iteration in range(1, self.config.max_iterations + 1):
            item_step = item_stepper(
                latent0=latent,
                item_responses=item_responses,
                item_mask=item_mask,
                theta=theta,
                family_state=self.family_.state_dict(),
                a_scale=moments.a_scale,
            )
            item_step_is_finite = (
                np.all(np.isfinite(item_step.latent_modes))
                and np.all(np.isfinite(item_step.hessian))
                and np.all(np.isfinite(item_step.laplace_nll))
            )
            if not item_step_is_finite:
                self.stopping_reason_ = "numerical_failure"
                self.failure_iteration_ = iteration
                break
            latent_new = np.asarray(item_step.latent_modes, dtype=float)
            latent_new = np.nan_to_num(latent_new, nan=0.0, posinf=10.0, neginf=-10.0)
            latent_new = np.clip(latent_new, -10.0, 10.0)
            posterior_nodes, posterior_covariance, node_weights = laplace_cubature(
                latent_new, item_step.hessian
            )
            node_weights = np.broadcast_to(
                node_weights, posterior_nodes.shape[:2]
            ).copy()
            latent_reference = latent.copy()
            latent_new, latent_reference, theta_scaled, posterior_nodes, alpha_shift = (
                self._identify_discrimination(
                    latent_new, latent_reference, theta, posterior_nodes
                    , node_weights
                )
            )
            self.family_.fit_weighted(
                posterior_nodes[:, :, : self.population_dimension], node_weights
            )
            shift = float(self.family_.moments().b_center)
            latent_new, theta_norm, moments = self._normalize_identification(
                latent_new, theta_scaled
            )
            latent_reference[:, 0] -= shift
            posterior_nodes = self._normalize_nodes(posterior_nodes, shift)
            theta_new = update_theta(
                theta_start=theta_norm,
                responses=person_responses,
                mask=person_mask,
                posterior_nodes=posterior_nodes,
                node_weights=node_weights,
                model_dim=self.model_dimension,
                a_scale=moments.a_scale,
                bounds=self.config.theta_bounds,
            )

            theta_change = float(np.max(np.abs(theta_new - theta_norm)))
            latent_change = float(np.max(np.abs(latent_new - latent_reference)))
            theta_rms_change = float(np.sqrt(np.mean((theta_new - theta_norm) ** 2)))
            item_rms_change = float(np.sqrt(np.mean((latent_new - latent_reference) ** 2)))
            laplace_total = float(np.sum(item_step.laplace_nll))
            relative_objective_change = (
                np.inf
                if previous_nll is None
                else abs(laplace_total - previous_nll) / (1.0 + abs(previous_nll))
            )
            objective_increased = (
                previous_nll is not None
                and (laplace_total - previous_nll) / (1.0 + abs(previous_nll)) > 1e-5
            )
            if objective_increased:
                objective_increase_count += 1
                consecutive_objective_increases += 1
            else:
                consecutive_objective_increases = 0

            current_predictions = self._predict_with_nodes(
                theta_new,
                posterior_nodes,
                node_weights,
                sampled_person,
                sampled_item,
            )
            prediction_rms_change = (
                np.inf
                if previous_predictions is None
                else float(
                    np.sqrt(np.mean((current_predictions - previous_predictions) ** 2))
                )
            )

            criteria_met = (
                iteration >= self.config.min_iterations
                and relative_objective_change < self.config.objective_tolerance
                and prediction_rms_change < self.config.prediction_tolerance
                and not objective_increased
            )
            stable_iterations = stable_iterations + 1 if criteria_met else 0

            self.history_.append(
                {
                    "iteration": iteration,
                    "theta_change": theta_change,
                    "latent_change": latent_change,
                    "theta_rms_change": theta_rms_change,
                    "item_rms_change": item_rms_change,
                    "laplace_nll": laplace_total,
                    "relative_objective_change": relative_objective_change,
                    "prediction_rms_change": prediction_rms_change,
                    "objective_increased": objective_increased,
                    "stable_iterations": stable_iterations,
                    "alpha_identification_shift": alpha_shift,
                    "b_mean": float(moments.b_center),
                }
            )

            latent = latent_new
            theta = theta_new
            self.family_moments_ = moments
            self.item_hessian_ = item_step.hessian
            self.item_laplace_nll_ = item_step.laplace_nll
            self.item_posterior_covariance_ = posterior_covariance
            self.posterior_nodes_ = posterior_nodes
            self.node_weights_ = node_weights

            if laplace_total < best_nll:
                best_nll = laplace_total
                self.selected_iteration_ = iteration
                best_snapshot = {
                    "theta": theta.copy(),
                    "latent": latent.copy(),
                    "family": copy.deepcopy(self.family_),
                    "family_moments": copy.deepcopy(self.family_moments_),
                    "item_hessian": np.asarray(self.item_hessian_).copy(),
                    "item_laplace_nll": np.asarray(self.item_laplace_nll_).copy(),
                    "posterior_covariance": np.asarray(
                        self.item_posterior_covariance_
                    ).copy(),
                    "posterior_nodes": np.asarray(self.posterior_nodes_).copy(),
                    "node_weights": np.asarray(self.node_weights_).copy(),
                }

            if self.config.verbose:
                print(
                    f"[iter {iteration:02d}] "
                    f"laplace_nll={laplace_total:.3f} "
                    f"rel_obj={relative_objective_change:.3e} "
                    f"pred_rms={prediction_rms_change:.3e} "
                    f"theta_rms={theta_rms_change:.3e} "
                    f"item_rms={item_rms_change:.3e} "
                    f"patience={stable_iterations}/{self.config.convergence_patience}"
                )

            previous_nll = laplace_total
            previous_predictions = current_predictions
            if consecutive_objective_increases >= 5:
                self.stopping_reason_ = "objective_divergence"
                self.failure_iteration_ = iteration
                if best_snapshot is None:
                    raise FloatingPointError("No finite state was available to restore.")
                theta = best_snapshot["theta"]
                latent = best_snapshot["latent"]
                self.family_ = best_snapshot["family"]
                self.family_moments_ = best_snapshot["family_moments"]
                self.item_hessian_ = best_snapshot["item_hessian"]
                self.item_laplace_nll_ = best_snapshot["item_laplace_nll"]
                self.item_posterior_covariance_ = best_snapshot[
                    "posterior_covariance"
                ]
                self.posterior_nodes_ = best_snapshot["posterior_nodes"]
                self.node_weights_ = best_snapshot["node_weights"]
                break
            if stable_iterations >= self.config.convergence_patience:
                self.stopping_reason_ = "convergence_criteria"
                break

        if self.stopping_reason_ == "numerical_failure":
            if self.posterior_nodes_ is None:
                raise FloatingPointError("The first item update produced nonfinite values.")
            self.theta_ = theta
            self.latent_modes_ = latent
            self.item_params_ = natural_item_parameters_numpy(
                latent=latent,
                model_dim=self.model_dimension,
                a_scale=self.family_moments_.a_scale,
            )
            self.objective_increase_count_ = objective_increase_count
            return self

        final_step = item_stepper(
            latent0=latent,
            item_responses=item_responses,
            item_mask=item_mask,
            theta=theta,
            family_state=self.family_.state_dict(),
            a_scale=self.family_moments_.a_scale,
        )
        latent = np.asarray(final_step.latent_modes, dtype=float)
        posterior_nodes, posterior_covariance, node_weights = laplace_cubature(
            latent, final_step.hessian
        )
        node_weights = np.broadcast_to(node_weights, posterior_nodes.shape[:2]).copy()
        latent, _, theta, posterior_nodes, _ = self._identify_discrimination(
            latent, latent, theta, posterior_nodes, node_weights
        )
        self.family_.fit_weighted(
            posterior_nodes[:, :, : self.population_dimension], node_weights
        )
        shift = float(self.family_.moments().b_center)
        latent, theta, moments = self._normalize_identification(latent, theta)
        posterior_nodes = self._normalize_nodes(posterior_nodes, shift)
        theta = update_theta(
            theta_start=theta,
            responses=person_responses,
            mask=person_mask,
            posterior_nodes=posterior_nodes,
            node_weights=node_weights,
            model_dim=self.model_dimension,
            a_scale=moments.a_scale,
            bounds=self.config.theta_bounds,
        )
        self.theta_ = theta
        self.latent_modes_ = latent
        self.item_hessian_ = final_step.hessian
        self.item_laplace_nll_ = final_step.laplace_nll
        self.item_posterior_covariance_ = posterior_covariance
        self.posterior_nodes_ = posterior_nodes
        self.node_weights_ = node_weights
        self.family_moments_ = moments
        self.item_params_ = natural_item_parameters_numpy(
            latent=latent,
            model_dim=self.model_dimension,
            a_scale=self.family_moments_.a_scale,
        )
        self.objective_increase_count_ = objective_increase_count
        self.laplace_theta_ = self.theta_.copy()
        self.laplace_population_ = copy.deepcopy(self.family_moments_)
        if self.config.integration == "aghq":
            self._refine_with_aghq(
                item_responses=item_responses,
                item_mask=item_mask,
                person_responses=person_responses,
                person_mask=person_mask,
                sampled_person=sampled_person,
                sampled_item=sampled_item,
                item_stepper=item_stepper,
            )
        return self

    def _refine_with_aghq(
        self,
        item_responses,
        item_mask,
        person_responses,
        person_mask,
        sampled_person,
        sampled_item,
        item_stepper,
    ) -> None:
        """Refine a converged Laplace fit at increasing AGHQ orders."""

        theta = self.theta_.copy()
        latent = self.latent_modes_.copy()
        previous_order = None
        previous_theta = None
        previous_population = None
        previous_predictions = None
        previous_objective = None
        previous_within_order_converged = False
        self.integration_diagnostics_ = []
        self.integration_stable_ = False
        self.aghq_stopping_reason_ = "maximum_quadrature_order_without_stability"

        for order_index, order in enumerate(self.config.aghq_orders):
            stable_iterations = 0
            iteration_predictions = None
            iteration_objective = None
            for iteration in range(1, self.config.aghq_max_iterations + 1):
                item_step = item_stepper(
                    latent0=latent,
                    item_responses=item_responses,
                    item_mask=item_mask,
                    theta=theta,
                    family_state=self.family_.state_dict(),
                    a_scale=self.family_moments_.a_scale,
                )
                modes = np.clip(
                    np.nan_to_num(
                        item_step.latent_modes, nan=0.0, posinf=10.0, neginf=-10.0
                    ),
                    -10.0,
                    10.0,
                )
                moments_before = self.family_.moments()
                population_before = self._population_vector(moments_before)
                quadrature = adaptive_gauss_hermite(
                    modes=modes,
                    hessians=item_step.hessian,
                    responses=item_responses,
                    mask=item_mask,
                    theta=theta,
                    population_mean=moments_before.raw_mean,
                    population_covariance=moments_before.raw_cov,
                    model_dimension=self.model_dimension,
                    points=order,
                    batch_size=self.config.aghq_batch_size,
                )
                nodes = quadrature.nodes
                weights = quadrature.weights
                objective = -float(np.sum(quadrature.log_integrals))
                reference = latent.copy()
                modes, reference, theta_scaled, nodes, alpha_shift = (
                    self._identify_discrimination(
                        modes, reference, theta, nodes, weights
                    )
                )
                self.family_.fit_weighted(nodes, weights)
                shift = float(self.family_.moments().b_center)
                modes, theta_normalized, moments = self._normalize_identification(
                    modes, theta_scaled
                )
                reference[:, 0] -= shift
                nodes = self._normalize_nodes(nodes, shift)
                theta_new = update_theta(
                    theta_start=theta_normalized,
                    responses=person_responses,
                    mask=person_mask,
                    posterior_nodes=nodes,
                    node_weights=weights,
                    model_dim=self.model_dimension,
                    a_scale=moments.a_scale,
                    bounds=self.config.theta_bounds,
                )
                predictions = self._predict_with_nodes(
                    theta_new,
                    nodes,
                    weights,
                    sampled_person,
                    sampled_item,
                )
                theta_rms = float(np.sqrt(np.mean((theta_new - theta_normalized) ** 2)))
                population_max = float(
                    np.max(
                        np.abs(
                            self._population_vector(moments) - population_before
                        )
                    )
                )
                prediction_rms = (
                    np.inf
                    if iteration_predictions is None
                    else float(
                        np.sqrt(np.mean((predictions - iteration_predictions) ** 2))
                    )
                )
                relative_objective = (
                    np.inf
                    if iteration_objective is None
                    else abs(objective - iteration_objective)
                    / (1.0 + abs(iteration_objective))
                )
                converged = (
                    iteration >= self.config.aghq_min_iterations
                    and theta_rms < self.config.aghq_inner_theta_tolerance
                    and population_max
                    < self.config.aghq_inner_population_tolerance
                    and prediction_rms
                    < self.config.aghq_inner_prediction_tolerance
                    and relative_objective
                    < self.config.aghq_inner_objective_tolerance
                )
                stable_iterations = stable_iterations + 1 if converged else 0
                self.history_.append(
                    {
                        "phase": "aghq_refinement",
                        "aghq_order": order,
                        "aghq_iteration": iteration,
                        "theta_rms_change": theta_rms,
                        "population_max_change": population_max,
                        "item_rms_change": float(
                            np.sqrt(np.mean((modes - reference) ** 2))
                        ),
                        "aghq_nll": objective,
                        "relative_objective_change": relative_objective,
                        "prediction_rms_change": prediction_rms,
                        "stable_iterations": stable_iterations,
                        "alpha_identification_shift": alpha_shift,
                    }
                )
                theta = theta_new
                latent = modes
                self.family_moments_ = moments
                iteration_predictions = predictions
                iteration_objective = objective
                self.item_hessian_ = item_step.hessian
                self.posterior_nodes_ = nodes
                self.node_weights_ = weights
                self.item_posterior_covariance_ = self._posterior_covariance(
                    nodes, weights
                )
                self.aghq_log_integrals_ = quadrature.log_integrals
                if stable_iterations >= self.config.aghq_patience:
                    break

            # Re-evaluate the reported state after the final M-step. This keeps
            # the objective, score, predictions, and saved posterior rule on the
            # same parameter iterate.
            precheck_objective = iteration_objective
            precheck_predictions = iteration_predictions.copy()
            final_step = item_stepper(
                latent0=latent,
                item_responses=item_responses,
                item_mask=item_mask,
                theta=theta,
                family_state=self.family_.state_dict(),
                a_scale=self.family_moments_.a_scale,
            )
            latent = np.clip(
                np.nan_to_num(
                    final_step.latent_modes, nan=0.0, posinf=10.0, neginf=-10.0
                ),
                -10.0,
                10.0,
            )
            final_quadrature = adaptive_gauss_hermite(
                modes=latent,
                hessians=final_step.hessian,
                responses=item_responses,
                mask=item_mask,
                theta=theta,
                population_mean=self.family_moments_.raw_mean,
                population_covariance=self.family_moments_.raw_cov,
                model_dimension=self.model_dimension,
                points=order,
                batch_size=self.config.aghq_batch_size,
            )
            nodes = final_quadrature.nodes
            weights = final_quadrature.weights
            iteration_objective = -float(np.sum(final_quadrature.log_integrals))
            iteration_predictions = self._predict_with_nodes(
                theta,
                nodes,
                weights,
                sampled_person,
                sampled_item,
            )
            score_max = self._posterior_score_max(
                theta, nodes, weights, item_responses, item_mask
            )
            population = self._population_vector(self.family_moments_)
            posterior_item_means = np.einsum("jk,jkd->jd", weights, nodes)
            posterior_mean = np.mean(posterior_item_means, axis=0)
            posterior_second = (
                np.einsum("jk,jkd,jke->de", weights, nodes, nodes) / len(nodes)
            )
            posterior_covariance = posterior_second - np.outer(
                posterior_mean, posterior_mean
            )
            if self.config.covariance == "diagonal":
                posterior_covariance = np.diag(np.diag(posterior_covariance))
            posterior_population = np.concatenate(
                (
                    posterior_mean,
                    posterior_covariance[
                        np.triu_indices_from(posterior_covariance)
                    ],
                )
            )
            final_population_residual = float(
                np.max(np.abs(posterior_population - population))
            )
            final_prediction_recheck = float(
                np.sqrt(
                    np.mean((iteration_predictions - precheck_predictions) ** 2)
                )
            )
            final_objective_recheck = float(
                abs(iteration_objective - precheck_objective)
                / (1.0 + abs(precheck_objective))
            )
            within_order_converged = (
                stable_iterations >= self.config.aghq_patience
                and final_population_residual
                < self.config.aghq_inner_population_tolerance
                and final_prediction_recheck
                < self.config.aghq_inner_prediction_tolerance
                and final_objective_recheck
                < self.config.aghq_inner_objective_tolerance
                and score_max < self.config.aghq_score_tolerance
            )
            correlation = (
                float(self.family_moments_.raw_corr[0, 1])
                if self.model_dimension == 2
                else 0.0
            )
            theta_max_change = (
                np.inf
                if previous_theta is None
                else float(np.max(np.abs(theta - previous_theta)))
            )
            correlation_change = (
                np.inf
                if previous_order is None
                else abs(correlation - previous_correlation)
            )
            population_change = (
                np.inf
                if previous_population is None
                else float(np.max(np.abs(population - previous_population)))
            )
            prediction_change = (
                np.inf
                if previous_predictions is None
                else float(
                    np.sqrt(np.mean((iteration_predictions - previous_predictions) ** 2))
                )
            )
            order_objective_change = (
                np.inf
                if previous_objective is None
                else abs(iteration_objective - previous_objective)
                / (1.0 + abs(previous_objective))
            )
            order_stable = (
                previous_order is not None
                and previous_within_order_converged
                and within_order_converged
                and theta_max_change < self.config.aghq_theta_tolerance
                and population_change < self.config.aghq_population_tolerance
                and correlation_change < self.config.aghq_correlation_tolerance
                and prediction_change < self.config.aghq_prediction_tolerance
                and order_objective_change < self.config.aghq_objective_tolerance
                and score_max < self.config.aghq_score_tolerance
            )
            self.integration_diagnostics_.append(
                {
                    "aghq_order": order,
                    "iterations": iteration,
                    "within_order_converged": within_order_converged,
                    "final_population_fixed_point_residual": final_population_residual,
                    "final_prediction_recheck": final_prediction_recheck,
                    "final_relative_objective_recheck": final_objective_recheck,
                    "theta_max_change_from_previous_order": theta_max_change,
                    "population_max_change_from_previous_order": population_change,
                    "correlation_change_from_previous_order": correlation_change,
                    "prediction_rms_change_from_previous_order": prediction_change,
                    "relative_objective_change_from_previous_order": order_objective_change,
                    "score_infinity_norm": score_max,
                    "order_stable": order_stable,
                }
            )
            previous_order = order
            previous_theta = theta.copy()
            previous_population = population.copy()
            previous_correlation = correlation
            previous_predictions = iteration_predictions.copy()
            previous_objective = iteration_objective
            previous_within_order_converged = within_order_converged
            self.item_hessian_ = final_step.hessian
            self.posterior_nodes_ = nodes
            self.node_weights_ = weights
            self.item_posterior_covariance_ = self._posterior_covariance(nodes, weights)
            self.aghq_log_integrals_ = final_quadrature.log_integrals
            if order_stable and order_index >= 1:
                self.integration_stable_ = True
                self.aghq_stopping_reason_ = "nested_order_stability"
                break

        self.theta_ = theta
        self.latent_modes_ = latent
        self.item_params_ = natural_item_parameters_numpy(
            latent, self.model_dimension, self.family_moments_.a_scale
        )
        self.selected_aghq_order_ = previous_order

    def estimate_inference(
        self,
        clusters: Optional[np.ndarray] = None,
        posterior_draw_target: int = 32_000,
        maximum_draws_per_item: int = 32,
        resampling_seeds: tuple[int, ...] = (17041, 29063),
        batch_size: Optional[int] = None,
        check_order_stability: bool = True,
    ) -> InferenceResult:
        """Estimate joint capability and item-population uncertainty.

        The sensitivity matrix uses Louis' identity with the selected AGHQ
        posterior rule. The sandwich meat is formed from item scores or from
        caller-supplied item-cluster score sums.
        """

        if (
            self.theta_ is None
            or self.posterior_nodes_ is None
            or self.node_weights_ is None
            or self.family_moments_ is None
            or self.item_responses_ is None
            or self.item_mask_ is None
        ):
            raise RuntimeError("Model has not been fit yet.")
        if self.config.integration != "aghq":
            raise RuntimeError("Validated inference requires the selected AGHQ rule.")
        self.inference_result_ = estimate_inference(
            theta=self.theta_,
            posterior_nodes=self.posterior_nodes_,
            node_weights=self.node_weights_,
            item_responses=self.item_responses_,
            item_mask=self.item_mask_,
            population_covariance=self.family_moments_.raw_cov,
            model_dimension=self.model_dimension,
            covariance_structure=self.config.covariance,
            clusters=clusters,
            posterior_draw_target=posterior_draw_target,
            maximum_draws_per_item=maximum_draws_per_item,
            resampling_seeds=resampling_seeds,
            batch_size=batch_size or min(self.config.aghq_batch_size, 32),
        )
        selected_order = int(self.selected_aghq_order_)
        order_index = self.config.aghq_orders.index(selected_order)
        if check_order_stability and order_index > 0:
            previous_order = int(self.config.aghq_orders[order_index - 1])
            previous_quadrature = adaptive_gauss_hermite(
                modes=self.latent_modes_,
                hessians=self.item_hessian_,
                responses=self.item_responses_,
                mask=self.item_mask_,
                theta=self.theta_,
                population_mean=self.family_moments_.raw_mean,
                population_covariance=self.family_moments_.raw_cov,
                model_dimension=self.model_dimension,
                points=previous_order,
                batch_size=self.config.aghq_batch_size,
            )
            previous_inference = estimate_inference(
                theta=self.theta_,
                posterior_nodes=previous_quadrature.nodes,
                node_weights=previous_quadrature.weights,
                item_responses=self.item_responses_,
                item_mask=self.item_mask_,
                population_covariance=self.family_moments_.raw_cov,
                model_dimension=self.model_dimension,
                covariance_structure=self.config.covariance,
                clusters=clusters,
                posterior_draw_target=posterior_draw_target,
                maximum_draws_per_item=maximum_draws_per_item,
                resampling_seeds=resampling_seeds,
                batch_size=batch_size or min(self.config.aghq_batch_size, 32),
            )
            selected_se = self.inference_result_.parameter_table[
                "sandwich_se"
            ].to_numpy(dtype=float)
            previous_se = previous_inference.parameter_table[
                "sandwich_se"
            ].to_numpy(dtype=float)
            valid = (
                np.isfinite(selected_se)
                & np.isfinite(previous_se)
                & (selected_se > 0.0)
                & (previous_se > 0.0)
            )
            if np.all(valid):
                denominator = np.maximum(
                    0.5 * (selected_se + previous_se), 1e-12
                )
                order_relative_change = float(
                    np.max(np.abs(selected_se - previous_se) / denominator)
                )
            else:
                order_relative_change = np.inf
            order_stable = bool(order_relative_change <= 0.10)
            self.inference_result_.diagnostics.update(
                {
                    "previous_aghq_order_for_inference": previous_order,
                    "quadrature_order_se_relative_change": order_relative_change,
                    "quadrature_order_inference_stable": order_stable,
                    "inference_admissible": bool(
                        self.inference_result_.diagnostics["inference_admissible"]
                        and previous_inference.diagnostics["inference_admissible"]
                        and order_stable
                    ),
                }
            )
        else:
            self.inference_result_.diagnostics.update(
                {
                    "previous_aghq_order_for_inference": None,
                    "quadrature_order_se_relative_change": np.nan,
                    "quadrature_order_inference_stable": not check_order_stability,
                    "inference_admissible": bool(
                        self.inference_result_.diagnostics["inference_admissible"]
                        and not check_order_stability
                    ),
                }
            )
        return self.inference_result_


    def predict_pairs(
        self, person_index, item_index, theta: Optional[np.ndarray] = None
    ) -> np.ndarray:
        if self.item_params_ is None or self.posterior_nodes_ is None:
            raise RuntimeError("Model has not been fit yet.")
        theta_use = self.theta_ if theta is None else np.asarray(theta, dtype=float)
        person_index = np.asarray(person_index)
        item_index = np.asarray(item_index)
        return self._predict_with_nodes(
            theta_use,
            self.posterior_nodes_,
            self.node_weights_,
            person_index,
            item_index,
        )

    def score_subjects(
        self, matrix: np.ndarray, theta_init: Optional[np.ndarray] = None
    ) -> np.ndarray:
        """Estimate capabilities with the fitted item population held fixed."""

        if self.posterior_nodes_ is None or self.family_moments_ is None:
            raise RuntimeError("Model has not been fit yet.")
        matrix = np.asarray(matrix, dtype=float)
        if matrix.ndim != 2 or matrix.shape[1] != self.posterior_nodes_.shape[0]:
            raise ValueError(
                f"responses must have {self.posterior_nodes_.shape[0]} item columns"
            )
        observed = np.isfinite(matrix)
        if np.any(np.sum(observed, axis=1) == 0):
            raise ValueError("every scored subject must have an observed response")
        responses = np.nan_to_num(matrix, nan=0.0)
        start = (
            theta_start(matrix)
            if theta_init is None
            else np.asarray(theta_init, dtype=float)
        )
        if start.shape != (matrix.shape[0],):
            raise ValueError(f"theta_init must have shape ({matrix.shape[0]},)")
        return update_theta_predictive(
            theta_start=start,
            responses=responses,
            mask=observed.astype(float),
            posterior_nodes=self.posterior_nodes_,
            node_weights=self.node_weights_,
            model_dim=self.model_dimension,
            bounds=self.config.theta_bounds,
        )

    def item_frame(self) -> pd.DataFrame:
        if self.item_params_ is None or self.latent_modes_ is None:
            raise RuntimeError("Model has not been fit yet.")
        data = {
            "item_id": np.arange(self.latent_modes_.shape[0]),
            "b": self.item_params_["b"],
            "a": self.item_params_["a"],
            "latent_b": self.latent_modes_[:, 0],
        }
        if self.model_dimension >= 2:
            data["latent_alpha"] = self.latent_modes_[:, 1]
        return pd.DataFrame(data)

    def latent_correlation_frame(self) -> pd.DataFrame:
        if self.family_moments_ is None:
            raise RuntimeError("Model has not been fit yet.")
        names = ["b", "alpha"][: self.population_dimension]
        rows = []
        for i, name_i in enumerate(names):
            for j, name_j in enumerate(names):
                rows.append(
                    {
                        "parameter_1": name_i,
                        "parameter_2": name_j,
                        "correlation": float(self.family_moments_.raw_corr[i, j]),
                    }
                )
        return pd.DataFrame(rows)

    def history_frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.history_)

    def integration_frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.integration_diagnostics_)

    def summary(self) -> Dict[str, float]:
        if self.item_params_ is None or self.theta_ is None:
            raise RuntimeError("Model has not been fit yet.")
        natural = self.item_params_

        def pair_corr(x, y):
            x = np.asarray(x, dtype=float)
            y = np.asarray(y, dtype=float)
            if np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
                return np.nan
            return float(np.corrcoef(x, y)[0, 1])

        out = {
            "model": self.config.model,
            "item_population": "normal",
            "covariance": self.config.covariance,
            "population_dimension": self.population_dimension,
            "theta_estimator": "posterior_averaged_mle",
            "integration": (
                "laplace_initialized_adaptive_gauss_hermite"
                if self.config.integration == "aghq"
                else "laplace_gaussian_cubature"
            ),
            "n_persons": int(self.theta_.shape[0]),
            "n_items": int(self.latent_modes_.shape[0]),
            "outer_iterations": int(len(self.history_)),
            "stopping_reason": (
                getattr(self, "aghq_stopping_reason_", self.stopping_reason_)
                if self.config.integration == "aghq"
                else self.stopping_reason_
            ),
            "laplace_stopping_reason": self.stopping_reason_,
            "failure_iteration": self.failure_iteration_,
            "selected_iteration": self.selected_iteration_,
            "objective_increase_count": int(getattr(self, "objective_increase_count_", 0)),
            "objective_increase_patience": 5,
            "objective_tolerance": self.config.objective_tolerance,
            "prediction_tolerance": self.config.prediction_tolerance,
            "convergence_patience": self.config.convergence_patience,
            "convergence_sample_size": self.config.convergence_sample_size,
            "laplace_nll": float(np.sum(self.item_laplace_nll_)),
            "auxiliary_item_mode_count": int(self.latent_modes_.size),
            "theta_mean": float(np.mean(self.theta_)),
            "theta_sd": float(np.std(self.theta_)),
            "corr_b_a_items": pair_corr(natural["b"], natural["a"]),
        }
        if self.config.integration == "aghq" and hasattr(
            self, "selected_aghq_order_"
        ):
            out.update(
                {
                    "selected_aghq_order": int(self.selected_aghq_order_),
                    "aghq_order_stable": bool(self.integration_stable_),
                    "admissible": bool(self.integration_stable_),
                    "aghq_orders_evaluated": [
                        int(row["aghq_order"])
                        for row in self.integration_diagnostics_
                    ],
                    "aghq_nll": -float(np.sum(self.aghq_log_integrals_)),
                    "laplace_to_aghq_theta_max_change": float(
                        np.max(np.abs(self.theta_ - self.laplace_theta_))
                    ),
                    "aghq_stability_tolerances": {
                        "inner_theta_rms": self.config.aghq_inner_theta_tolerance,
                        "inner_population_max": self.config.aghq_inner_population_tolerance,
                        "inner_prediction_rms": self.config.aghq_inner_prediction_tolerance,
                        "inner_relative_objective": self.config.aghq_inner_objective_tolerance,
                        "theta_max": self.config.aghq_theta_tolerance,
                        "population_max": self.config.aghq_population_tolerance,
                        "correlation": self.config.aghq_correlation_tolerance,
                        "prediction_rms": self.config.aghq_prediction_tolerance,
                        "relative_objective": self.config.aghq_objective_tolerance,
                        "normalized_score_infinity": self.config.aghq_score_tolerance,
                    },
                }
            )
        elif self.config.integration == "aghq":
            out.update(
                {
                    "selected_aghq_order": None,
                    "aghq_order_stable": False,
                    "admissible": False,
                    "aghq_orders_evaluated": [],
                }
            )
        else:
            out["admissible"] = self.stopping_reason_ == "convergence_criteria"
        if self.inference_result_ is not None:
            out.update(
                {
                    "inference_admissible": bool(
                        self.inference_result_.diagnostics["inference_admissible"]
                    ),
                    "inference_method": self.inference_result_.diagnostics["method"],
                    "inference_condition_number": self.inference_result_.diagnostics[
                        "sensitivity_condition_number"
                    ],
                    "inference_resampling_se_relative_change": self.inference_result_.diagnostics[
                        "resampling_se_relative_change"
                    ],
                    "inference_quadrature_order_se_relative_change": self.inference_result_.diagnostics[
                        "quadrature_order_se_relative_change"
                    ],
                    "inference_quadrature_order_stable": self.inference_result_.diagnostics[
                        "quadrature_order_inference_stable"
                    ],
                }
            )
        out["population_corr_b_log_a"] = (
            float(self.family_moments_.raw_corr[0, 1])
            if self.population_dimension >= 2
            else np.nan
        )
        population_covariance = np.asarray(self.family_moments_.raw_cov, dtype=float)
        population_mean = np.asarray(self.family_moments_.raw_mean, dtype=float)
        out["population_mean_b"] = float(population_mean[0])
        out["population_variance_b"] = float(population_covariance[0, 0])
        out["population_sd_b"] = float(
            np.sqrt(max(population_covariance[0, 0], 0.0))
        )
        if self.population_dimension >= 2:
            out["population_mean_log_a"] = float(population_mean[1])
            out["population_variance_log_a"] = float(population_covariance[1, 1])
            out["population_sd_log_a"] = float(
                np.sqrt(max(population_covariance[1, 1], 0.0))
            )
            out["population_cov_b_log_a"] = float(population_covariance[0, 1])
        return out
