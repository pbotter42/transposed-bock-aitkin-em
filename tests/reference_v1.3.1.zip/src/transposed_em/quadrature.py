from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from numpy.polynomial.hermite import hermgauss
from scipy.special import logsumexp

from .models import natural_item_parameters_numpy


@dataclass
class QuadratureResult:
    nodes: np.ndarray
    weights: np.ndarray
    log_integrals: np.ndarray


def adaptive_gauss_hermite(
    modes: np.ndarray,
    hessians: np.ndarray,
    responses: np.ndarray,
    mask: np.ndarray,
    theta: np.ndarray,
    population_mean: np.ndarray,
    population_covariance: np.ndarray,
    model_dimension: int,
    points: int,
    batch_size: int = 512,
) -> QuadratureResult:
    """Compute item-specific AGHQ nodes, posterior weights, and integrals."""

    modes = np.asarray(modes, dtype=float)
    hessians = np.asarray(hessians, dtype=float)
    responses = np.asarray(responses, dtype=float)
    mask = np.asarray(mask, dtype=float)
    theta = np.asarray(theta, dtype=float)
    dimension = modes.shape[1]
    if dimension != model_dimension:
        raise ValueError("mode and model dimensions differ")
    one_dimensional_nodes, one_dimensional_weights = hermgauss(points)
    meshes = np.meshgrid(*([one_dimensional_nodes] * dimension), indexing="ij")
    base = np.column_stack([mesh.ravel() for mesh in meshes])
    weight_meshes = np.meshgrid(*([one_dimensional_weights] * dimension), indexing="ij")
    base_weights = np.prod(np.stack(weight_meshes), axis=0).ravel()
    log_base_weight = np.log(base_weights) + np.sum(base**2, axis=1)
    node_count = len(base)
    item_count = len(modes)
    output_nodes = np.empty((item_count, node_count, dimension), dtype=float)
    output_weights = np.empty((item_count, node_count), dtype=float)
    output_integrals = np.empty(item_count, dtype=float)
    precision = np.linalg.inv(population_covariance)
    prior_logdet = float(np.linalg.slogdet(population_covariance)[1])
    prior_constant = dimension * math.log(2.0 * math.pi) + prior_logdet

    for start in range(0, item_count, batch_size):
        stop = min(start + batch_size, item_count)
        batch_hessian = 0.5 * (
            hessians[start:stop] + np.swapaxes(hessians[start:stop], 1, 2)
        )
        eigenvalues, eigenvectors = np.linalg.eigh(batch_hessian)
        eigenvalues = np.clip(eigenvalues, 1e-8, 1e8)
        covariance = np.einsum(
            "bij,bj,bkj->bik", eigenvectors, 1.0 / eigenvalues, eigenvectors
        )
        roots = np.linalg.cholesky(covariance)
        nodes = modes[start:stop, None, :] + np.sqrt(2.0) * np.einsum(
            "kd,bed->bke", base, roots
        )
        output_nodes[start:stop] = nodes
        centered = nodes - population_mean[None, None, :]
        prior_quadratic = np.einsum("bkd,de,bke->bk", centered, precision, centered)
        log_posterior = -0.5 * (prior_quadratic + prior_constant)
        parameters = natural_item_parameters_numpy(
            nodes.reshape(-1, dimension), model_dimension
        )
        discrimination = parameters["a"].reshape(stop - start, node_count)
        difficulty = parameters["b"].reshape(stop - start, node_count)
        linear = discrimination[:, :, None] * (
            theta[None, None, :] - difficulty[:, :, None]
        )
        batch_response = responses[start:stop, None, :]
        batch_mask = mask[start:stop, None, :]
        log_likelihood = np.sum(
            batch_mask * (batch_response * linear - np.logaddexp(0.0, linear)),
            axis=2,
        )
        log_kernel = log_base_weight[None, :] + log_posterior + log_likelihood
        normalization = logsumexp(log_kernel, axis=1)
        output_weights[start:stop] = np.exp(log_kernel - normalization[:, None])
        output_integrals[start:stop] = (
            0.5 * dimension * math.log(2.0)
            + np.log(np.diagonal(roots, axis1=1, axis2=2)).sum(axis=1)
            + normalization
        )
    return QuadratureResult(output_nodes, output_weights, output_integrals)

