from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from .model import TransposedIRT


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fit a normal random-item 1PL or 2PL model."
    )
    parser.add_argument(
        "responses", type=Path, help="CSV with subjects in rows and items in columns"
    )
    parser.add_argument("--output", type=Path, default=Path("transposed_em_results"))
    parser.add_argument("--model", choices=("1pl", "2pl"), default="2pl")
    parser.add_argument("--covariance", choices=("diagonal", "full"))
    parser.add_argument("--integration", choices=("aghq", "laplace"), default="aghq")
    parser.add_argument("--aghq-orders", default="7,11,15,21")
    parser.add_argument("--aghq-max-iterations", type=int, default=50)
    parser.add_argument("--max-iterations", type=int, default=200)
    parser.add_argument(
        "--inference",
        action="store_true",
        help="Write joint model-based and cluster-sandwich uncertainty artifacts.",
    )
    parser.add_argument(
        "--item-clusters",
        type=Path,
        help="Optional one-column CSV of item-cluster labels in response-column order.",
    )
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    responses = pd.read_csv(args.responses, index_col=0)
    fit = TransposedIRT(
        model=args.model,
        covariance=args.covariance,
        integration=args.integration,
        max_iterations=args.max_iterations,
        aghq_orders=tuple(int(value) for value in args.aghq_orders.split(",")),
        aghq_max_iterations=args.aghq_max_iterations,
        verbose=args.verbose,
    ).fit(responses)
    args.output.mkdir(parents=True, exist_ok=True)
    fit.abilities().to_csv(args.output / "abilities.csv", index=False)
    fit.items().to_csv(args.output / "items.csv", index=False)
    fit.history().to_csv(args.output / "history.csv", index=False)
    fit.integration_diagnostics().to_csv(
        args.output / "integration_diagnostics.csv", index=False
    )
    if args.inference:
        clusters = None
        if args.item_clusters is not None:
            cluster_frame = pd.read_csv(args.item_clusters)
            if cluster_frame.shape[1] != 1:
                raise ValueError("item-clusters must contain exactly one column")
            clusters = cluster_frame.iloc[:, 0].to_numpy()
            if len(clusters) != responses.shape[1]:
                raise ValueError(
                    "item-clusters must have one row per response-matrix item"
                )
        inference = fit.estimate_inference(clusters=clusters)
        inference.to_csv(args.output / "parameter_inference.csv", index=False)
        fit.covariance("sandwich").to_csv(
            args.output / "covariance_sandwich.csv", index=True
        )
        fit.covariance("model_based").to_csv(
            args.output / "covariance_model_based.csv", index=True
        )
        (args.output / "inference_diagnostics.json").write_text(
            json.dumps(
                fit.inference_diagnostics(), indent=2, sort_keys=True, default=float
            )
            + "\n"
        )
    (args.output / "summary.json").write_text(
        json.dumps(fit.summary(), indent=2, sort_keys=True, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
