from __future__ import annotations

from dataclasses import dataclass


MODEL_DIMENSION = {"1pl": 1, "2pl": 2}


@dataclass(frozen=True)
class FitConfig:
    """Numerical controls for the normal random-item estimator."""

    model: str = "2pl"
    covariance: str = "full"
    integration: str = "aghq"
    max_iterations: int = 200
    item_newton_steps: int = 6
    theta_bounds: tuple[float, float] = (-6.0, 6.0)
    objective_tolerance: float = 1e-5
    prediction_tolerance: float = 1e-4
    convergence_patience: int = 5
    min_iterations: int = 10
    convergence_sample_size: int = 10_000
    ridge: float = 1e-4
    random_state: int = 0
    verbose: bool = False
    aghq_orders: tuple[int, ...] = (7, 11, 15, 21)
    aghq_max_iterations: int = 50
    aghq_min_iterations: int = 2
    aghq_patience: int = 3
    aghq_batch_size: int = 512
    aghq_inner_theta_tolerance: float = 2e-3
    aghq_inner_population_tolerance: float = 2e-3
    aghq_inner_prediction_tolerance: float = 5e-4
    aghq_inner_objective_tolerance: float = 1e-5
    aghq_theta_tolerance: float = 1e-2
    aghq_population_tolerance: float = 1e-2
    aghq_correlation_tolerance: float = 1e-2
    aghq_prediction_tolerance: float = 2e-3
    aghq_objective_tolerance: float = 1e-4
    aghq_score_tolerance: float = 1e-3

    def __post_init__(self) -> None:
        model = self.model.lower()
        covariance = self.covariance.lower()
        integration = self.integration.lower()
        object.__setattr__(self, "model", model)
        object.__setattr__(self, "covariance", covariance)
        object.__setattr__(self, "integration", integration)
        if model not in MODEL_DIMENSION:
            raise ValueError("model must be '1pl' or '2pl'")
        if covariance not in {"diagonal", "full"}:
            raise ValueError("covariance must be 'diagonal' or 'full'")
        if model == "1pl" and covariance != "diagonal":
            raise ValueError("The 1PL has one item coordinate; use covariance='diagonal'.")
        if integration not in {"aghq", "laplace"}:
            raise ValueError("integration must be 'aghq' or 'laplace'")
        if self.max_iterations < 1 or self.item_newton_steps < 1:
            raise ValueError("iteration counts must be positive")
        if self.min_iterations < 1 or self.min_iterations > self.max_iterations:
            raise ValueError("min_iterations must be between 1 and max_iterations")
        if self.convergence_patience < 1:
            raise ValueError("convergence_patience must be positive")
        if self.objective_tolerance <= 0 or self.prediction_tolerance <= 0:
            raise ValueError("convergence tolerances must be positive")
        lower, upper = self.theta_bounds
        if not lower < upper:
            raise ValueError("theta_bounds must be increasing")
        if self.ridge <= 0:
            raise ValueError("ridge must be positive")
        if not self.aghq_orders or any(
            order < 3 or order % 2 == 0 for order in self.aghq_orders
        ):
            raise ValueError("aghq_orders must contain positive odd integers of at least 3")
        if tuple(sorted(set(self.aghq_orders))) != self.aghq_orders:
            raise ValueError("aghq_orders must be strictly increasing")
        if self.aghq_max_iterations < 1 or self.aghq_min_iterations < 1:
            raise ValueError("AGHQ iteration counts must be positive")
        if self.aghq_min_iterations > self.aghq_max_iterations:
            raise ValueError("aghq_min_iterations cannot exceed aghq_max_iterations")
        if self.aghq_patience < 1 or self.aghq_batch_size < 1:
            raise ValueError("AGHQ patience and batch size must be positive")
        aghq_tolerances = (
            self.aghq_inner_theta_tolerance,
            self.aghq_inner_population_tolerance,
            self.aghq_inner_prediction_tolerance,
            self.aghq_inner_objective_tolerance,
            self.aghq_theta_tolerance,
            self.aghq_population_tolerance,
            self.aghq_correlation_tolerance,
            self.aghq_prediction_tolerance,
            self.aghq_objective_tolerance,
            self.aghq_score_tolerance,
        )
        if any(value <= 0.0 for value in aghq_tolerances):
            raise ValueError("AGHQ tolerances must be positive")

    @property
    def dimension(self) -> int:
        return MODEL_DIMENSION[self.model]
