from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .models import irt_probability_numpy, natural_item_parameters_numpy


@dataclass
class InferenceResult:
    parameter_table: pd.DataFrame
    free_parameter_covariance: np.ndarray
    model_based_covariance: np.ndarray
    sandwich_covariance: np.ndarray
    sensitivity: np.ndarray
    meat: np.ndarray
    item_scores: np.ndarray
    diagnostics: dict[str, object]


def population_free_parameters(
    covariance: np.ndarray, covariance_structure: str
) -> tuple[np.ndarray, list[str]]:
    covariance = np.asarray(covariance, dtype=float)
    sd = np.sqrt(np.maximum(np.diag(covariance), 1e-12))
    values = [float(np.log(sd[0]))]
    labels = ["log_sd_b"]
    if covariance.shape[0] == 2:
        values.append(float(np.log(sd[1])))
        labels.append("log_sd_log_a")
        if covariance_structure == "full":
            correlation = float(
                np.clip(covariance[0, 1] / (sd[0] * sd[1]), -0.999999, 0.999999)
            )
            values.append(float(np.arctanh(correlation)))
            labels.append("fisher_z_corr_b_log_a")
    return np.asarray(values, dtype=float), labels


def covariance_from_free(
    values: np.ndarray, dimension: int, covariance_structure: str
) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    sd_b = float(np.exp(values[0]))
    if dimension == 1:
        return np.array([[sd_b**2]], dtype=float)
    sd_alpha = float(np.exp(values[1]))
    correlation = (
        float(np.tanh(values[2])) if covariance_structure == "full" else 0.0
    )
    return np.array(
        [
            [sd_b**2, correlation * sd_b * sd_alpha],
            [correlation * sd_b * sd_alpha, sd_alpha**2],
        ],
        dtype=float,
    )


def covariance_derivatives(
    values: np.ndarray, dimension: int, covariance_structure: str
) -> list[np.ndarray]:
    covariance = covariance_from_free(values, dimension, covariance_structure)
    derivatives = [np.zeros_like(covariance) for _ in range(len(values))]
    derivatives[0][0, 0] = 2.0 * covariance[0, 0]
    if dimension == 2:
        derivatives[0][0, 1] = derivatives[0][1, 0] = covariance[0, 1]
        derivatives[1][1, 1] = 2.0 * covariance[1, 1]
        derivatives[1][0, 1] = derivatives[1][1, 0] = covariance[0, 1]
        if covariance_structure == "full":
            sd = np.exp(values[:2])
            correlation = float(np.tanh(values[2]))
            off_diagonal = (1.0 - correlation**2) * sd[0] * sd[1]
            derivatives[2][0, 1] = derivatives[2][1, 0] = off_diagonal
    return derivatives


def normal_covariance_score(
    latent: np.ndarray,
    free_values: np.ndarray,
    dimension: int,
    covariance_structure: str,
) -> np.ndarray:
    latent = np.asarray(latent, dtype=float)
    covariance = covariance_from_free(
        free_values, dimension, covariance_structure
    )
    precision = np.linalg.inv(covariance)
    transformed = np.einsum("...d,de->...e", latent, precision)
    scores = []
    for derivative in covariance_derivatives(
        free_values, dimension, covariance_structure
    ):
        trace = float(np.trace(precision @ derivative))
        quadratic = np.einsum(
            "...d,de,...e->...", transformed, derivative, transformed
        )
        scores.append(0.5 * (quadratic - trace))
    return np.stack(scores, axis=-1)


def normal_covariance_score_hessian(
    latent: np.ndarray,
    free_values: np.ndarray,
    dimension: int,
    covariance_structure: str,
    step: float = 1e-5,
) -> np.ndarray:
    columns = []
    for index in range(len(free_values)):
        delta = np.zeros_like(free_values)
        delta[index] = step
        plus = normal_covariance_score(
            latent, free_values + delta, dimension, covariance_structure
        )
        minus = normal_covariance_score(
            latent, free_values - delta, dimension, covariance_structure
        )
        columns.append((plus - minus) / (2.0 * step))
    hessian = np.stack(columns, axis=-1)
    return 0.5 * (hessian + np.swapaxes(hessian, -1, -2))


def _systematic_indices(
    weights: np.ndarray, draws: int, rng: np.random.Generator
) -> np.ndarray:
    cumulative = np.cumsum(weights, axis=1)
    cumulative[:, -1] = 1.0
    offsets = rng.random((weights.shape[0], 1))
    positions = (np.arange(draws, dtype=float)[None, :] + offsets) / draws
    return np.sum(positions[:, :, None] > cumulative[:, None, :], axis=2)


def _stable_inverse(matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray, float, bool]:
    matrix = 0.5 * (np.asarray(matrix, dtype=float) + np.asarray(matrix).T)
    eigenvalues, eigenvectors = np.linalg.eigh(matrix)
    maximum = float(np.max(eigenvalues))
    minimum = float(np.min(eigenvalues))
    positive = bool(minimum > max(1e-10, maximum * 1e-10))
    condition = float(maximum / minimum) if minimum > 0.0 else np.inf
    if not positive or condition > 1e10:
        return np.full_like(matrix, np.nan), eigenvalues, condition, False
    inverse = (eigenvectors / eigenvalues) @ eigenvectors.T
    return 0.5 * (inverse + inverse.T), eigenvalues, condition, True


def _natural_parameter_table(
    theta: np.ndarray,
    free_population: np.ndarray,
    free_covariance: np.ndarray,
    model_covariance: np.ndarray,
    sandwich_covariance: np.ndarray,
    population_dimension: int,
    covariance_structure: str,
) -> pd.DataFrame:
    n_subjects = len(theta)
    rows = []

    def add_row(label, kind, estimate, gradient):
        gradient = np.asarray(gradient, dtype=float)
        model_variance = float(gradient @ model_covariance @ gradient)
        sandwich_variance = float(gradient @ sandwich_covariance @ gradient)
        model_se = np.sqrt(max(model_variance, 0.0))
        sandwich_se = np.sqrt(max(sandwich_variance, 0.0))
        rows.append(
            {
                "parameter": label,
                "parameter_type": kind,
                "estimate": float(estimate),
                "model_based_se": float(model_se),
                "sandwich_se": float(sandwich_se),
                "sandwich_lower_95": float(estimate - 1.96 * sandwich_se),
                "sandwich_upper_95": float(estimate + 1.96 * sandwich_se),
            }
        )

    dimension = len(theta) + len(free_population)
    for index, estimate in enumerate(theta):
        gradient = np.zeros(dimension)
        gradient[index] = 1.0
        add_row(f"theta_{index}", "capability", estimate, gradient)

    sd_b = float(np.exp(free_population[0]))
    gradient = np.zeros(dimension)
    gradient[n_subjects] = sd_b
    add_row("sd_b", "item_population", sd_b, gradient)
    if population_dimension == 2:
        sd_alpha = float(np.exp(free_population[1]))
        gradient = np.zeros(dimension)
        gradient[n_subjects + 1] = sd_alpha
        add_row("sd_log_a", "item_population", sd_alpha, gradient)
        if covariance_structure == "full":
            correlation = float(np.tanh(free_population[2]))
            gradient = np.zeros(dimension)
            gradient[n_subjects + 2] = 1.0 - correlation**2
            add_row(
                "corr_b_log_a", "item_population", correlation, gradient
            )

    return pd.DataFrame(rows)


def estimate_inference(
    *,
    theta: np.ndarray,
    posterior_nodes: np.ndarray,
    node_weights: np.ndarray,
    item_responses: np.ndarray,
    item_mask: np.ndarray,
    population_covariance: np.ndarray,
    model_dimension: int,
    covariance_structure: str,
    clusters: np.ndarray | None = None,
    posterior_draw_target: int = 32_000,
    maximum_draws_per_item: int = 32,
    resampling_seeds: tuple[int, ...] = (17041, 29063),
    batch_size: int = 32,
    exact_moment_operation_limit: int = 5_000_000,
) -> InferenceResult:
    """Estimate joint model-based and cluster-sandwich covariance.

    The sensitivity uses Louis' identity with AGHQ posterior expectations.
    Posterior second moments are estimated by reproducible systematic draws
    from each item's normalized quadrature rule. Item score means, and hence
    the sandwich meat, use the complete quadrature rule.
    """

    theta = np.asarray(theta, dtype=float)
    nodes = np.asarray(posterior_nodes, dtype=float)
    weights = np.asarray(node_weights, dtype=float)
    responses = np.asarray(item_responses, dtype=float)
    mask = np.asarray(item_mask, dtype=float)
    item_count, node_count, latent_dimension = nodes.shape
    if latent_dimension != model_dimension:
        raise ValueError("posterior node dimension does not match the model")
    if weights.shape != (item_count, node_count):
        raise ValueError("node_weights has an incompatible shape")
    if responses.shape != mask.shape or responses.shape[0] != item_count:
        raise ValueError("item responses and masks have incompatible shapes")
    if responses.shape[1] != len(theta):
        raise ValueError("response subject count differs from theta")
    if posterior_draw_target < 1 or maximum_draws_per_item < 1:
        raise ValueError("posterior draw controls must be positive")
    if not resampling_seeds:
        raise ValueError("at least one resampling seed is required")

    weights = weights / np.sum(weights, axis=1, keepdims=True)
    free_population, population_labels = population_free_parameters(
        population_covariance, covariance_structure
    )
    parameter_count = len(theta) + len(free_population)
    item_scores = np.empty((item_count, parameter_count), dtype=float)
    use_exact_moments = bool(
        item_count * node_count * parameter_count <= exact_moment_operation_limit
    )
    draws_per_item = (
        node_count
        if use_exact_moments
        else min(
            maximum_draws_per_item,
            max(1, int(np.ceil(posterior_draw_target / item_count))),
        )
    )
    rngs = [np.random.default_rng(seed) for seed in resampling_seeds]
    expected_outer = [np.zeros((parameter_count, parameter_count)) for _ in rngs]
    expected_negative_hessian = [
        np.zeros((parameter_count, parameter_count)) for _ in rngs
    ]

    for start in range(0, item_count, batch_size):
        stop = min(start + batch_size, item_count)
        batch_nodes = nodes[start:stop]
        batch_weights = weights[start:stop]
        batch_count = stop - start
        natural = natural_item_parameters_numpy(
            batch_nodes.reshape(-1, latent_dimension), model_dimension
        )
        discrimination = natural["a"].reshape(batch_count, node_count)
        difficulty = natural["b"].reshape(batch_count, node_count)
        probability = irt_probability_numpy(
            theta[None, None, :],
            discrimination[:, :, None],
            difficulty[:, :, None],
        )
        theta_scores = (
            mask[start:stop, None, :]
            * discrimination[:, :, None]
            * (responses[start:stop, None, :] - probability)
        )
        population_scores = normal_covariance_score(
            batch_nodes,
            free_population,
            model_dimension,
            covariance_structure,
        )
        complete_scores = np.concatenate(
            (theta_scores, population_scores), axis=2
        )
        means = np.einsum("bk,bkd->bd", batch_weights, complete_scores)
        item_scores[start:stop] = means

        complete_theta_information = (
            mask[start:stop, None, :]
            * discrimination[:, :, None] ** 2
            * probability
            * (1.0 - probability)
        )
        if use_exact_moments:
            weighted_scores = complete_scores * np.sqrt(batch_weights)[:, :, None]
            flattened = weighted_scores.reshape(-1, parameter_count)
            outer_increment = flattened.T @ flattened
            theta_diagonal = np.sum(
                complete_theta_information * batch_weights[:, :, None],
                axis=(0, 1),
            )
            population_hessian = normal_covariance_score_hessian(
                batch_nodes,
                free_population,
                model_dimension,
                covariance_structure,
            )
            population_hessian_sum = np.einsum(
                "bk,bkde->de", batch_weights, population_hessian
            )
            for replicate in range(len(rngs)):
                expected_outer[replicate] += outer_increment
                expected_negative_hessian[replicate][
                    np.arange(len(theta)), np.arange(len(theta))
                ] += theta_diagonal
                expected_negative_hessian[replicate][
                    len(theta) :, len(theta) :
                ] -= population_hessian_sum
        else:
            for replicate, rng in enumerate(rngs):
                indices = _systematic_indices(
                    batch_weights, draws_per_item, rng
                )
                rows = np.arange(batch_count)[:, None]
                sampled_scores = complete_scores[rows, indices]
                flattened = sampled_scores.reshape(-1, parameter_count)
                expected_outer[replicate] += (
                    flattened.T @ flattened / draws_per_item
                )
                sampled_theta_information = complete_theta_information[
                    rows, indices
                ]
                theta_diagonal = np.sum(
                    sampled_theta_information, axis=(0, 1)
                ) / draws_per_item
                expected_negative_hessian[replicate][
                    np.arange(len(theta)), np.arange(len(theta))
                ] += theta_diagonal
                sampled_nodes = batch_nodes[rows, indices]
                population_hessian = normal_covariance_score_hessian(
                    sampled_nodes,
                    free_population,
                    model_dimension,
                    covariance_structure,
                )
                expected_negative_hessian[replicate][
                    len(theta) :, len(theta) :
                ] -= np.sum(population_hessian, axis=(0, 1)) / draws_per_item

    item_outer = item_scores.T @ item_scores
    sensitivity_replicates = [
        0.5
        * (
            expected_negative_hessian[index]
            - expected_outer[index]
            + item_outer
            + (
                expected_negative_hessian[index]
                - expected_outer[index]
                + item_outer
            ).T
        )
        for index in range(len(rngs))
    ]
    sensitivity = np.mean(sensitivity_replicates, axis=0)

    if clusters is None:
        cluster_scores = item_scores
    else:
        clusters = np.asarray(clusters)
        if clusters.shape != (item_count,):
            raise ValueError(f"clusters must have shape ({item_count},)")
        _, inverse = np.unique(clusters, return_inverse=True)
        cluster_scores = np.zeros((int(np.max(inverse)) + 1, parameter_count))
        np.add.at(cluster_scores, inverse, item_scores)
    cluster_scores = cluster_scores - np.mean(cluster_scores, axis=0, keepdims=True)
    cluster_count = len(cluster_scores)
    correction = cluster_count / (cluster_count - 1) if cluster_count > 1 else np.nan
    meat = correction * (cluster_scores.T @ cluster_scores)

    sensitivity_inverse, eigenvalues, condition, positive = _stable_inverse(
        sensitivity
    )
    if positive:
        model_covariance = sensitivity_inverse
        sandwich_covariance = (
            sensitivity_inverse @ meat @ sensitivity_inverse.T
        )
        sandwich_covariance = 0.5 * (
            sandwich_covariance + sandwich_covariance.T
        )
    else:
        model_covariance = np.full_like(sensitivity, np.nan)
        sandwich_covariance = np.full_like(sensitivity, np.nan)

    replicate_standard_errors = []
    for replicate_sensitivity in sensitivity_replicates:
        replicate_inverse, _, _, replicate_positive = _stable_inverse(
            replicate_sensitivity
        )
        if replicate_positive:
            covariance = replicate_inverse @ meat @ replicate_inverse.T
            replicate_standard_errors.append(
                np.sqrt(np.maximum(np.diag(covariance), 0.0))
            )
    if len(replicate_standard_errors) >= 2:
        stacked = np.stack(replicate_standard_errors)
        reference = np.maximum(np.mean(stacked, axis=0), 1e-12)
        resampling_relative_change = float(
            np.max(np.ptp(stacked, axis=0) / reference)
        )
    else:
        resampling_relative_change = np.nan

    free_values = np.concatenate((theta, free_population))
    free_labels = [f"theta_{index}" for index in range(len(theta))] + population_labels
    table = _natural_parameter_table(
        theta,
        free_population,
        np.zeros_like(sensitivity),
        model_covariance,
        sandwich_covariance,
        model_dimension,
        covariance_structure,
    )
    finite_standard_errors = bool(
        np.all(np.isfinite(table["sandwich_se"]))
        and np.all(table["sandwich_se"] > 0.0)
    )
    diagnostics = {
        "method": "AGHQ-Louis sensitivity with cluster-sandwich meat",
        "free_parameter_labels": free_labels,
        "free_parameter_estimates": free_values.tolist(),
        "posterior_nodes_per_item": int(node_count),
        "posterior_second_moment_method": (
            "full_quadrature" if use_exact_moments else "systematic_quadrature_resampling"
        ),
        "posterior_draws_per_item_per_replication": int(draws_per_item),
        "posterior_draw_replications": int(len(resampling_seeds)),
        "posterior_draw_total_per_replication": int(item_count * draws_per_item),
        "cluster_count": int(cluster_count),
        "sensitivity_min_eigenvalue": float(np.min(eigenvalues)),
        "sensitivity_max_eigenvalue": float(np.max(eigenvalues)),
        "sensitivity_condition_number": float(condition),
        "sensitivity_positive_definite": positive,
        "resampling_se_relative_change": resampling_relative_change,
        "finite_positive_standard_errors": finite_standard_errors,
        "inference_admissible": bool(
            positive
            and finite_standard_errors
            and (
                not np.isfinite(resampling_relative_change)
                or resampling_relative_change <= 0.10
            )
        ),
    }
    return InferenceResult(
        parameter_table=table,
        free_parameter_covariance=sandwich_covariance,
        model_based_covariance=model_covariance,
        sandwich_covariance=sandwich_covariance,
        sensitivity=sensitivity,
        meat=meat,
        item_scores=item_scores,
        diagnostics=diagnostics,
    )
